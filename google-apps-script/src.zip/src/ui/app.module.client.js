﻿console.log('spread2TS')
(function () {
    'use strict';

    console.log('angular');

    angular
        .module('spread2TS', [
            'ngResource']);

    var routerConfig = function ($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state('portal', {
                abstract: true,
                url: '/portal',
                templateUrl: url + "?page=test-template.html",
            })
            .state('login', {
                url: '/login',
                templateUrl: 'app/login/login.html',
                controller: 'LoginController'
            })
            /*.state('portal.portfolio', {
                url: '/portfolio',
                templateUrl: 'app/main/main.html',
                data: { pageTitle: 'Portfolio' },
                resolve: {
                    authorizationResolver: ['authenticationService',
                        function (authenticationService) {
                            return authenticationService.isAuthenticated();
                        }]
                }
            })*/;

        $urlRouterProvider.otherwise('/portal/portfolio');
    };

    routerConfig.$inject = ['$stateProvider', ' $urlRouterProvider'];

    angular
        .module('spread2TS')
        .config(routerConfig);

})();